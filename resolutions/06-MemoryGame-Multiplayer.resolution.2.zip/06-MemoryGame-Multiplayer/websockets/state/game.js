const games = new Map()
let currentGameID = 0

export const createGame = (difficulty, user) => {
    currentGameID++
    const game = {
        id: currentGameID,
        difficulty,
        creator: user.id,
        player1: user.id,
        player2: null,
    }
    games.set(currentGameID, game)
    return game
} 

export const getGames = () => {
    return games.values().toArray()
}
