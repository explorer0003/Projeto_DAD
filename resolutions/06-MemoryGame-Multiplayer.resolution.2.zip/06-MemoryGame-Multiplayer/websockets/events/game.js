import { getUser } from "../state/connection.js"
import { createGame, getGames } from "../state/game.js"

export const handleGameEvents = (io, socket) => {
    socket.on("create-game", (difficulty) => {
        const user = getUser(socket.id)
        const game = createGame(difficulty, user)
        socket.join(`game-${game.id}`)
        console.log(`[Game] ${user.name} created a new game - ID: ${game.id}`)
        io.emit("games", getGames())
    })
  
    socket.on("get-games", () => {
        io.emit("games", getGames())
    })
}
